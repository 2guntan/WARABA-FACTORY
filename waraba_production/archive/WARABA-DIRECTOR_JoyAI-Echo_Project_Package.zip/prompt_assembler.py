#!/usr/bin/env python3
"""
Prompt Assembler for WARABA-DIRECTOR + JoyAI-Echo

This script merges:
- CharacterProfile JSON (from Character Definition Tool)
- Storyboard shots (from WARABA-DIRECTOR)
into well-formed prompts ready for JoyAI-Echo.

Usage:
    python prompt_assembler.py --character leuk.json --shots storyboard_shots.json --output prompts.json
"""

import json
import argparse
from typing import Dict, List, Any


def load_json(path: str) -> Dict[str, Any]:
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def build_character_description(character: Dict[str, Any]) -> str:
    """Convert CharacterProfile into a rich text block for JoyAI-Echo prompts."""
    desc = f"{character.get('name', 'Character')}, a {character.get('age_appearance', '')} {character.get('species', '')}."
    
    if character.get('physical_description'):
        desc += f" {character['physical_description']}."
    if character.get('clothing'):
        desc += f" Wearing {character['clothing']}."
    if character.get('distinctive_features'):
        desc += f" {character['distinctive_features']}."
    
    if character.get('voice'):
        voice = character['voice']
        desc += f" Voice: {voice.get('timbre', '')}."
        if voice.get('tone'):
            desc += f" Tone: {voice['tone']}."
    
    if character.get('personality_traits'):
        traits = ", ".join(character['personality_traits'])
        desc += f" Personality: {traits}."
    
    return desc.strip()


def assemble_prompts(character: Dict[str, Any], shots: List[Dict[str, Any]]) -> List[str]:
    """Generate JoyAI-Echo compatible prompt strings from shots + character."""
    char_desc = build_character_description(character)
    prompts = []
    
    for shot in shots:
        shot_desc = shot.get("description", "")
        
        # Build structured prompt following JoyAI-Echo recommended format
        prompt = (
            f"Roles & Subjects: {char_desc} "
            f"{shot_desc} "
            f"Style: {shot.get('style', 'cinematic, realistic lighting, detailed fur and textures')} "
            f"Camera: {shot.get('camera', 'medium shot')} "
            f"Background: {shot.get('background', 'savanna clearing with acacia tree')} "
            f"Audio: {shot.get('audio', 'ambient savanna sounds, subtle wind')}"
        )
        prompts.append(prompt.strip())
    
    return prompts


def main():
    parser = argparse.ArgumentParser(description="Assemble prompts for JoyAI-Echo")
    parser.add_argument("--character", required=True, help="Path to CharacterProfile JSON")
    parser.add_argument("--shots", required=True, help="Path to shots list JSON")
    parser.add_argument("--output", default="joyai_echo_prompts.json", help="Output JSON file")
    args = parser.parse_args()

    character = load_json(args.character)
    shots_data = load_json(args.shots)
    shots = shots_data.get("shots", shots_data)  # support both formats

    prompts = assemble_prompts(character, shots)

    output = {
        "character_id": character.get("character_id"),
        "prompts": prompts
    }

    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print(f"✅ Generated {len(prompts)} prompts → {args.output}")


if __name__ == "__main__":
    main()