#!/usr/bin/env python3
"""
Enhanced Prompt Assembler v2 - Pre-loaded with Episode 01 shots

This version includes the actual shots from Episode 01 Storyboard Package
and demonstrates how to combine them with a CharacterProfile.
"""

import json
from typing import Dict, Any

# Pre-loaded Episode 01 shots (from WARABA-DIRECTOR Storyboard Package)
EPISODE_01_SHOTS = [
    {
        "shot_id": "SH001",
        "time": "00:00–00:08",
        "duration_sec": 8,
        "description": "Plan large d’ensemble, léger angle frontal. Établissement de la clairière et de l’arbre à palabres. L’assemblée est déjà réunie.",
        "camera": "Plan large d’ensemble, léger angle frontal",
        "style": "Cinematic, realistic lighting, warm twilight atmosphere",
        "background": "Savanna clearing with large acacia tree at dusk",
        "audio": "Griot voice in voice-over, subtle ambient savanna sounds"
    },
    {
        "shot_id": "SH007",
        "time": "00:46–00:56",
        "duration_sec": 10,
        "description": "Plan moyen dynamique. Le Singe bondit au centre et affirme qu’il vient de naître.",
        "camera": "Plan moyen dynamique",
        "style": "Dynamic camera movement, energetic",
        "background": "Center of the circle, animals reacting",
        "audio": "Singe voice, surprised reactions from the assembly"
    },
    {
        "shot_id": "SH011",
        "time": "01:16–01:24",
        "duration_sec": 8,
        "description": "Contre-plongée vers les branches. La voix de Leuk descend depuis le haut.",
        "camera": "Contre-plongée vers les branches",
        "style": "Dramatic low angle, tension building",
        "background": "Branches of the acacia tree, Leuk hidden above",
        "audio": "Leuk’s voice from above, sudden silence"
    },
    {
        "shot_id": "SH014",
        "time": "01:36–01:40",
        "duration_sec": 4,
        "description": "Plan large vertical. Trajectoire lisible de Leuk vers le centre du cercle.",
        "camera": "Plan large vertical, following the fall",
        "style": "Cinematic slow-motion feel, dramatic",
        "background": "Vertical view from branches to the center",
        "audio": "Silence, then soft impact and dust"
    },
    {
        "shot_id": "SH016",
        "time": "01:48–01:58",
        "duration_sec": 10,
        "description": "Plan moyen sur Leuk. Il ouvre un œil, se redresse, s’époussette et dit : « Me voici. »",
        "camera": "Plan moyen sur Leuk",
        "style": "Warm, comedic timing",
        "background": "Center of the circle, animals surrounding Leuk",
        "audio": "Leuk’s line, then loud laughter from the assembly"
    },
    {
        "shot_id": "SH019",
        "time": "02:20–02:32",
        "duration_sec": 12,
        "description": "Plan moyen final sur Leuk. Les regards convergent vers lui. La lumière se réchauffe légèrement.",
        "camera": "Plan moyen final, slight push-in",
        "style": "Warm golden light, slightly unsettling final smile",
        "background": "Circle of animals looking at Leuk",
        "audio": "Griot voice-over conclusion"
    }
]


def build_character_description(character: Dict[str, Any]) -> str:
    """Convert CharacterProfile into rich text for JoyAI-Echo."""
    parts = []
    
    name = character.get("name", "Character")
    age = character.get("age_appearance", "")
    species = character.get("species", "")
    
    parts.append(f"{name}, a {age} {species}.")
    
    if character.get("physical_description"):
        parts.append(character["physical_description"])
    if character.get("clothing"):
        parts.append(f"Wearing {character['clothing']}.")
    if character.get("distinctive_features"):
        parts.append(character["distinctive_features"])
    
    if character.get("voice"):
        voice = character["voice"]
        parts.append(f"Voice: {voice.get('timbre', '')}.")
    
    if character.get("personality_traits"):
        traits = ", ".join(character["personality_traits"])
        parts.append(f"Personality: {traits}.")
    
    return " ".join(parts)


def generate_episode_prompts(character: Dict[str, Any], shots: list = None) -> dict:
    """Generate full prompt set for Episode 01."""
    if shots is None:
        shots = EPISODE_01_SHOTS
    
    char_desc = build_character_description(character)
    prompts = []
    
    for shot in shots:
        prompt = (
            f"Roles & Subjects: {char_desc} "
            f"{shot['description']} "
            f"Style: {shot.get('style', 'cinematic realistic')} "
            f"Camera: {shot.get('camera', 'medium shot')} "
            f"Background: {shot.get('background', 'savanna clearing')} "
            f"Audio: {shot.get('audio', 'ambient sounds')}"
        )
        prompts.append({
            "shot_id": shot["shot_id"],
            "time": shot.get("time"),
            "prompt": prompt.strip()
        })
    
    return {
        "episode_id": "episode_01_le_plus_jeune_animal",
        "character_id": character.get("character_id"),
        "total_shots": len(prompts),
        "prompts": prompts
    }


# Example usage
if __name__ == "__main__":
    # Example Character (you can replace with your real JSON)
    example_character = {
        "character_id": "leuk_young_hare_v1",
        "name": "Leuk",
        "species": "Young hare",
        "age_appearance": "Young adult",
        "physical_description": "Slender and agile build, light brown fur with white underbelly, sharp intelligent eyes, long expressive ears",
        "clothing": "Simple light tunic",
        "distinctive_features": "Quick and precise movements, expressive eyebrows",
        "voice": {
            "timbre": "Clear young male voice with slight mischievous quality"
        },
        "personality_traits": ["clever", "observant", "slightly vain"]
    }
    
    result = generate_episode_prompts(example_character)
    
    print(json.dumps(result, indent=2, ensure_ascii=False))
    
    # Save to file
    with open("episode_01_joyai_prompts.json", "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    
    print("\n✅ Generated prompts saved to episode_01_joyai_prompts.json")